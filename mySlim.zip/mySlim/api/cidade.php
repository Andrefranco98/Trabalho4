<?php
$app->get('/api/cidades',function(){            // define um endpoint, dá todas as cidades da base de dados
    require_once('db/dbconnect.php');
    foreach($db->cidade()
         ->order("descr")
         //->limit(2,2)
         as $row) {
       $data[] = $row;
    }
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
});

// SELECT COM WHERE  // mostrar por id (/cidades/id)
$app->get('/api/cidade/{id}', function($request){
    $id = $request->getAttribute('id');
    require_once('db/dbconnect.php');
    foreach ($db->cidade()
                ->select('id', 'descr ')
                ->where('id', $id)
                as $row) {
        $data[] = $row;
    }
    if (isset($data)) {
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
    } else {
        echo json_encode("Esta cidade não existe.", JSON_UNESCAPED_UNICODE);
    }
});

// SELECT 1st city
$app->get('/api/cidades/teste',function(){
    require_once('db/dbconnect.php');

    foreach ($db->cidade()
                ->where('descr like ?', '%celos%')
                ->where('pais_id', 1)
                as $row) {
        $data[] = $row;
    }

    //$data2 = $db->cidade();
  ///  $data = $data2[1];
    if (isset($data)) {
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
    } else {
        echo json_encode("Sem cidade associada.", JSON_UNESCAPED_UNICODE);
    }
});

/* JOIN */
// DETALHE DA CIDADE
$app->get('/api/cidadesdetalhe',function(){
    require_once('db/dbconnect.php');
    $meuarray = array();
    foreach ($db->cidade()
                ->order("descr")
                as $row) {
        array_push($meuarray,array(
          'cidade' => $row["descr"],
          'pais' => $row->pais["descr"]
        ));
    }
    echo json_encode($meuarray, JSON_UNESCAPED_UNICODE);
});

$app->get('/api/cidade/{id}/pais',function($request){
$id = $request->getAttribute('id');
require_once('db/dbconnect.php');
$row = $db->cidade();
if (isset($row[$id])){
  echo json_encode($row[$id]->pais["descr"], JSON_UNESCAPED_UNICODE);
} else {
  echo json_encode("A cidade nao existe.", JSON_UNESCAPED_UNICODE);
}
});

// PESSOAS QUE PERTENCEM À CIDADE X
$app->get('/api/cidade/{id}/pessoas',function($request){
  $id = $request->getAttribute('id');
  require_once('db/dbconnect.php');

  foreach ($db->cidade()
        ->where('id', $id)
        as $row) {
        $pessoas = array();
        foreach($row->cidade_pessoa() as $linhan) {
          $pessoas[] = $linhan->pessoa["nome"];
        }
        if(isset($pessoas)) {
          echo json_encode($pessoas, JSON_UNESCAPED_UNICODE);
        } else {
          echo json_encode("Sem pessoas associadas à cidade", JSON_UNESCAPED_UNICODE);
        }
  }
});


/* POST */

$app->post('/api/cidade', function($request){
  require_once('db/dbconnect.php');
  $descr = $_POST["descr"];
  $idpais = $_POST["pais_id"];
  $data = array(
    "descr" => $descr,
    "pais_id" => $idpais
  );
  $cidade = $db->cidade();
  $result = $cidade->insert($data);

  if($result == false) {
    $result = ['status' => false, 'MSG' => "Inserção falhou"];
    echo json_encode($result, JSON_UNESCAPED_UNICODE);
  } else {
    $result = ['status' => true, 'MSG' => "Registo inserido tem o id " .
        $result["id"]];
    echo json_encode($result, JSON_UNESCAPED_UNICODE);
  }
});


/* PUT */ //ATUALIZACAO DE DADOS

$app->put('/api/cidade/{id}', function($request){
  require_once('db/dbconnect.php');
  $id = $request->getAttribute('id');
  $descr = $request->getParsedBody()['descr'];
  $idpais = $request->getParsedBody()['pais_id'];
  $data = array(
    "descr" => $descr,
    "pais_id" => $idpais
  );
  if(isset($db->cidade[$id])) {
    $result = $db->cidade[$id]->update($data);
    if($result) {
      echo json_encode("Registo atualizado", JSON_UNESCAPED_UNICODE);
    } else {
      echo json_encode("Erro na atualização dos dados.", JSON_UNESCAPED_UNICODE
        );
    }
  } else {
    echo json_enconde("Registo não existe", JSON_UNESCAPED_UNICODE);
  }
});

/* DELETE */

// DELETE
$app->delete('/api/cidade/{id}', function($request){
  require_once('db/dbconnect.php');
  $id = $request->getAttribute('id');
  $cidade = $db->cidade[$id];
  if($cidade){
    $result = $cidade->delete();
    if($result){
    $result = ['status' => true, 'msg' => 'registo apagado com sucesso'];
    echo json_encode($result, JSON_UNESCAPED_UNICODE);
    } else {
    $result = ['status' => false, 'msg' => 'erro a apagar registo'];
    echo json_encode($result, JSON_UNESCAPED_UNICODE);
  }
}
  else {
    $result = ['status' => false, 'msg' => 'registo nao existe'];
    echo json_encode($result, JSON_UNESCAPED_UNICODE);
  }
});
