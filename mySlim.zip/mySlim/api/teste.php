<?php

$app->get('/hello/{name}',function($request){
    echo "Hello "  . $request->getAttribute('name');; 
});
?>